function updateClock() {
  const now = new Date();

  const ukTime = new Date(now.toLocaleString("en-GB", { timeZone: "Europe/London" }));

  const hours = ukTime.getHours();
  const minutes = ukTime.getMinutes();
  const seconds = ukTime.getSeconds();

  let realMinutes = hours * 60 + minutes + seconds / 60;
  let minutesSinceStart = (realMinutes - 14 * 60 + 1440) % 1440;

  let cycleMinutes = minutesSinceStart % 15;

  let gameMinutes;

  if (cycleMinutes <= 14) {
    gameMinutes = cycleMinutes * 60;
  } else {
    let nightProgress = cycleMinutes - 14;
    gameMinutes = (14 * 60) + (nightProgress * 600);
  }

  let totalGameMinutes = 7 * 60 + gameMinutes;
  totalGameMinutes %= (24 * 60);

  let gHours = Math.floor(totalGameMinutes / 60);
  let gMinutes = Math.floor(totalGameMinutes % 60);

  let displayHour = gHours % 12 || 12;
  let ampm = gHours >= 12 ? "PM" : "AM";

  document.getElementById("clock").textContent =
    `${displayHour}:${gMinutes.toString().padStart(2, '0')} ${ampm}`;

  document.getElementById("phase").textContent =
    (cycleMinutes <= 14)
      ? "☀️ Daytime (1 hour/min)"
      : "🌙 Night (whole night in 1 min)";
}

setInterval(updateClock, 100);
updateClock();
  let gHours = Math.floor(totalGameMinutes / 60);
  let gMinutes = Math.floor(totalGameMinutes % 60);

  let displayHour = gHours % 12 || 12;
  let ampm = gHours >= 12 ? "PM" : "AM";

  document.getElementById("clock").textContent =
    `${displayHour}:${gMinutes.toString().padStart(2, '0')} ${ampm}`;

  document.getElementById("phase").textContent =
    (cycleMinutes <= 14)
      ? "☀️ Daytime (1 hour/min)"
      : "🌙 Night (whole night in 1 min)";
}

setInterval(updateClock, 100);
updateClock();